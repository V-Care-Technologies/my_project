@extends('front.layouts.app')


@section('content')
    <section class="breadcrub_section">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        My Cart
                    </li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="cart_details">
        <div class="container">
            <form action="">
                <div class="row">
                    @if (isset($list[0]))
                        <div class="col-lg-12 col-12 d-xl-inline d-sm-inline d-none">
                            <table class="aa-cartbox-summary">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Quantity</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>


                                    @foreach ($list as $data)
                                        <tr id="cart_box{{ $data->attr_id }}">
                                            <td>
                                                <div class="d-flex  align-items-center">
                                                    <span class="product_box mb-0"><img
                                                            src="{{ asset('storage/app/public/media/' . $data->image) }}"
                                                            class="cart_product w-100" /></span>
                                                    <div>
                                                        <span>{{ $data->title }}</span>
                                                        @if ($data->size != '')
                                                            <p class="mb-1 text-start mt-2">SIZE: {{ $data->size }}</p>
                                                        @endif
                                                        @if ($data->color != '')
                                                            <p class="mb-0 text-start">COLOR: {{ $data->color }}</p>
                                                        @endif
                                                    </div>

                                                </div>
                                            </td>
                                            <td class="p-0">
                                                <span style="font-size: 24px">{{ $data->price }}</span>
                                                <span>AED</span>
                                            </td>
                                            <td>
                                                <div class="qty-container">
                                                    {{-- <i class="fa fa-minus qty-btn-minus"></i> --}}
                                                    <input type="number" id="qty{{ $data->attr_id }}" name="qty"
                                                        value="{{ $data->qty }}" class="input-qty"
                                                        oninput="validateQty(this)"
                                                        onchange="updateQty('{{ $data->pid }}','{{ $data->size }}','{{ $data->color }}','{{ $data->attr_id }}','{{ $data->price }}')" />
                                                    {{-- <i class="fa fa-plus qty-btn-plus"></i> --}}
                                                </div>
                                            </td>
                                            <td>

                                                <span id="total_price_{{ $data->attr_id }}" style="font-size: 24px">
                                                    {{ $data->price * $data->qty }}AED
                                                </span>

                                            </td>
                                            <td><a class="remove" href="javascript:void(0)"
                                                    onclick="deleteCartProduct('{{ $data->pid }}','{{ $data->size }}','{{ $data->color }}','{{ $data->attr_id }}')">
                                                    <fa class="fa fa-close"></fa>
                                                </a></td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>

                            <div class="footer_btn mt-5 text-center aa-cartbox-summary">
                                <a href="{{ url('/checkout') }}" class="main-btn"><img
                                        src="{{ asset('public/front/images/checkout.svg') }}" class="pe-3" />Checkout</a>
                            </div>
                        </div>
                    @else
                        <h3>Cart empty</h3>
                    @endif

                </div>
            </form>
        </div>
    </section>
    <input type="hidden" id="qty" value="1" />
    <form id="frmAddToCart">
        <input type="hidden" id="size_id" name="size_id" />
        <input type="hidden" id="color_id" name="color_id" />
        <input type="hidden" id="pqty" name="pqty" />
        <input type="hidden" id="product_id" name="product_id" />
        @csrf
    </form>
    <script>
        function validateQty(input) {
            // Remove any non-numeric characters and leading zeros
            input.value = input.value.replace(/[^0-9]/g, '').replace(/^0+/, '');
        }

        function updateQty(pid, size, color, attr_id, price) {
            jQuery('#color_id').val(color);
            jQuery('#size_id').val(size);
            var qty = jQuery('#qty' + attr_id).val();
            jQuery('#qty').val(qty)
            add_to_cart(pid, size, color);
            jQuery('#total_price_' + attr_id).html('Rs ' + qty * price);
        }

        function add_to_cart(id, size_str_id, color_str_id) {

            jQuery('#add_to_cart_msg').html('');
            var color_id = jQuery('#color_id').val();
            var size_id = jQuery('#size_id').val();

            if (size_str_id == 0) {
                size_id = 'no';
            }
            if (color_str_id == 0) {
                color_id = 'no';
            }
            if (size_id == '' && size_id != 'no') {
                jQuery('#add_to_cart_msg').html(
                    '<div class="alert alert-danger fade in alert-dismissible mt10"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Please select size</div>'
                );
            } else if (color_id == '' && color_id != 'no') {
                jQuery('#add_to_cart_msg').html(
                    '<div class="alert alert-danger fade in alert-dismissible mt10"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Please select color</div>'
                );
            } else {
                jQuery('#product_id').val(id);
                jQuery('#pqty').val(jQuery('#qty').val());
                jQuery.ajax({
                    url: "{{ url('add_to_cart') }}",
                    method: 'POST',
                    data: jQuery('#frmAddToCart').serialize(),
                    success: function(result) {
                        var totalPrice = 0;

                        if (result.msg == 'not_avaliable') {
                            alert(result.data);
                        } else {
                            alert("Product " + result.msg);
                            if (result.totalItem == 0) {
                                jQuery('.aa-cart-notify').html('0');
                                jQuery('.aa-cartbox-summary').remove();
                            } else {

                                jQuery('.aa-cart-notify').html(result.totalItem);
                                var html = '<ul>';
                                jQuery.each(result.data, function(arrKey, arrVal) {
                                    totalPrice = parseInt(totalPrice) + (parseInt(arrVal.qty) *
                                        parseInt(arrVal.price));
                                    html += '<li><a class="aa-cartbox-img" href="#"><img src="' +
                                        PRODUCT_IMAGE + '/' + arrVal.image +
                                        '" alt="img"></a><div class="aa-cartbox-info"><h4><a href="#">' +
                                        arrVal.name + '</a></h4><p> ' + arrVal.qty + ' * Rs  ' + arrVal
                                        .price + '</p></div></li>';
                                });

                            }
                            html +=
                                '<li><span class="aa-cartbox-total-title">Total</span><span class="aa-cartbox-total-price">Rs ' +
                                totalPrice + '</span></li>';
                            html += '</ul><a class="aa-cartbox-checkout aa-primary-btn" href="cart">Cart</a>';

                            jQuery('.aa-cartbox-summary').html(html);
                        }
                    }
                });
            }
        }
    </script>

@endsection
