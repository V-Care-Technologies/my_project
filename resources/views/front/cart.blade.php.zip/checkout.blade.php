@extends('front.layouts.app')


@section('content')
    <section class="breadcrub_section">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Payment Summary</li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="payment_summary">
        <div class="container">
            <form id="frmPlaceOrder" data-cc-on-file="false" data-stripe-publishable-key="{{ env('STRIPE_KEY') }}">
                <div class="row">
                    <div class="col-12  d-xl-none d-lg-none d-sm-none d-lg-block">
                        <div class="product_row">
                            <span class="product_box">
                                <img src="images/cart_product1.png" class="cart_product">
                            </span>
                            <div class="product_text">
                                <h4>Myts Rooky Rooster See Saw Orange</h4>
                                <div class="payment_responsive">
                                    <div class="extra_div">
                                        <span class="qty-container">
                                            <i class="fa fa-minus qty-btn-minus"></i>
                                            <input type="text" name="qty" value="1" class="input-qty" />
                                            <i class="fa fa-plus qty-btn-plus"></i>
                                        </span>
                                        <div class="price">18,00 <span>AED</span></div>
                                    </div>
                                    <img src="images/delete_icon.svg" class="delete_icon">
                                </div>
                            </div>
                        </div>
                        <div class="product_row mb-3">
                            <span class="product_box">
                                <img src="images/cart_product1.png" class="cart_product">
                            </span>
                            <div class="product_text">
                                <h4>Myts Rooky Rooster See Saw Orange</h4>
                                <div class="payment_responsive">
                                    <div class="extra_div">
                                        <span class="qty-container">
                                            <i class="fa fa-minus qty-btn-minus"></i>
                                            <input type="text" name="qty" value="1" class="input-qty" />
                                            <i class="fa fa-plus qty-btn-plus"></i>
                                        </span>
                                        <div class="price">18,00 <span>AED</span></div>
                                    </div>
                                    <img src="images/delete_icon.svg" class="delete_icon">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-12 d-xl-inline d-sm-inline d-none">
                        <div class="row detail_row">
                            <div class="col-lg-6">
                                <div class="date">
                                    <p>Estimated delivery: 24 May 2023</p>
                                </div>
                            </div>
                            <div class="col-lg-6 justify-content-end d-flex">
                                <div class="date">
                                    <p>item (3)</p>
                                </div>
                            </div>
                        </div>
                        @php
                            $totalPrice = 0;
                        @endphp
                        @foreach ($cart_data as $list)
                            @php
                                $totalPrice = $totalPrice + $list->price * $list->qty;
                            @endphp
                            <div class="row product_row">
                                <div class="col-lg-5">
                                    <div class="product_box_main">
                                        <span class="product_box"><img
                                                src="{{ asset('public/storage/media/' . $list->image) }}"
                                                class="cart_product"></span>
                                        <span class="product_name">{{ $list->title }} ({{ $list->color }},
                                            {{ $list->size }}Kg)</span>
                                    </div>
                                </div>
                                <div class="col-lg-2">
                                    <h4 class="product_price">
                                        <span>{{ $list->price * $list->qty }}</span>AED
                                    </h4>
                                </div>

                            </div>
                        @endforeach

                        <div class="row summary_form">
                            <div class="col-lg-10">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input_box">
                                            <h5>First Name</h5>
                                            <input type="text" name="name" value="{{ $customers['name'] }}"
                                                placeholder="First Name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input_box">
                                            <h5>Last Name</h5>
                                            <input type="text" name="last_name" value="{{ $customers['last_name'] }}"
                                                placeholder="Last Name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input_box">
                                            <h5>Email</h5>
                                            <input type="email" name="email" value="{{ $customers['email'] }}"
                                                placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input_box">
                                            <h5>Phone Number</h5>
                                            <input type="text"name="mobile" required value="{{ $customers['mobile'] }}"
                                                id="mobile_code" class=" appointment_input" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="input_box">
                                            <h5>Address.....</h5>
                                            <textarea placeholder="Address....." name="address" rows="5">{{ $customers['address'] }}</textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input_box">
                                            <h5>City/distric</h5>
                                            <input type="text"name="city" required class=" appointment_input"
                                                value="{{ $customers['city'] }}" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input_box">
                                            <h5>Enter your PIN code</h5>
                                            <input type="text" name="zip" value="{{ $customers['zip'] }}"
                                                required class=" appointment_input" placeholder="PIN Number">
                                        </div>
                                    </div>
                                    {{-- <div class="col-lg-12">
                                <div class="input_box">
                                    <h5>Landmark</h5>
                                    <input type="text" name="phone" id="mobile_code" class=" appointment_input" placeholder="Phone Number">
                                </div>
                            </div> --}}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-12">
                        <div class="cart_total_box">
                            <div class="items_total">
                                <table class="total_table w-100">
                                    <tbody>
                                        @php
                                            $totalPrice = 0;
                                        @endphp
                                        @foreach ($cart_data as $list)
                                            @php
                                                $totalPrice = $totalPrice + $list->price * $list->qty;
                                            @endphp
                                            <tr>
                                                <td>{{ $list->title }} <strong> x {{ $list->qty }}</strong>
                                                    <br />
                                                    <span class="cart_color">{{ $list->color }}</span>
                                                </td>
                                                <td>AED {{ $list->price * $list->qty }}</td>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td>Total</td>
                                            <td id="total_price">AED {{ $totalPrice }}</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        </div>


                        <h4 class="coupon_heading">Coupon Code</h4>
                        <div class="aa-payment-method coupon_code d-flex justify-content-center">
                            <div class="remove_code">

                            </div>
                            <div class="hide show_coupon_box" id="coupon_box" style="display:none;">
                                <p class="d-flex align-items-center justify-content-center pt-3 mb-3 ">
                                    <span> Coupon Code : <span id="coupon_code_str"></span> <a href="javascript:void(0)"
                                            onclick="remove_coupon_code()" class="remove_coupon_code_link"><i
                                                class="fa-regular fa-trash-can"></i></a></span>
                                </p>
                            </div>
                            <input type="text" placeholder="Coupon Code"
                                class="form-control col-7 w-auto apply_coupon_code_box" name="coupon_code"
                                id="coupon_code">
                            <button type="button" class="main-btn col-5 apply_coupon_code_box border-0"
                                onclick="applyCouponCode()">Apply Coupon</button>
                            <div id="coupon_code_msg"></div>
                        </div>
                        <br />
                        <div class="payment_footer">
                            <p>Safe and secure payments Easy 100% Authenic products</p>
                            <div class="aa-payment-method">
                                <div class="payment_method d-flex align-items-center justify-content-center">
                                    <div class="cod_method">
                                        <input type="radio" id="cod" name="payment_type" value="COD" checked>
                                        <label for="cod" class="bordered_btn w-100">Cash on Delivery </label>
                                    </div>
                                    <div class="instamogo">
                                        <input type="radio" id="instamojo" name="payment_type" value="Gateway">
                                        <label for="instamojo" class="bordered_btn w-100 ms-3">Via Instamojo </label>
                                    </div>
                                </div>
                                <div class="submit_btn mt-5 m-auto text-center">
                                    <button type="submit" class="aa-browse-btn main-btn border-0"
                                        id="btnPlaceOrder">Place Order</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @csrf
            </form>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"
        integrity="sha256-2Pmvv0kuTBOenSvLm6bvfBSSHrUJ+3A7x6P5Ebd07/g=" crossorigin="anonymous"></script>
    <script>
        function applyCouponCode() {
            jQuery('#coupon_code_msg').html('');
            jQuery('#order_place_msg').html('');
            jQuery('.show_coupon_box').hide();
            var coupon_code = jQuery('#coupon_code').val();
            if (coupon_code != '') {
                jQuery.ajax({
                    type: 'post',
                    url: "{{ url('apply_coupon_code') }}",
                    data: 'coupon_code=' + coupon_code + '&_token=' + jQuery("[name='_token']").val(),
                    success: function(result) {
                        console.log(result.status);
                        if (result.status == 'success') {
                            jQuery('.show_coupon_box').removeClass('hide');
                            jQuery('#coupon_code_str').html(coupon_code);
                            jQuery('#total_price').html('AUD ' + result.totalPrice);
                            jQuery('.apply_coupon_code_box').hide();
                            jQuery('#coupon_box').show();
                        } else {

                        }
                        jQuery('#coupon_code_msg').html(result.msg);
                    }
                });
            } else {
                jQuery('#coupon_code_msg').html('Please enter coupon code');
            }
        }

        jQuery('#frmPlaceOrder').submit(function(e) {

            jQuery('#order_place_msg').html("Please wait...");
            e.preventDefault();
            jQuery.ajax({
                url: '{{ url('/place_order') }}',
                data: jQuery('#frmPlaceOrder').serialize(),
                type: 'post',
                success: function(result) {
                    if (result.status == 'success') {
                        if (result.payment_url != '') {
                            window.location.href = result.payment_url;
                        } else {
                            window.location.href = "./order_placed";
                        }

                    }
                    jQuery('#order_place_msg').html(result.msg);
                }
            });
        });

        function remove_coupon_code() {
            jQuery('#coupon_code_msg').html('');
            var coupon_code = jQuery('#coupon_code').val();
            jQuery('#coupon_code').val('');
            if (coupon_code != '') {
                jQuery.ajax({
                    type: 'post',
                    url: '{{ url('remove_coupon_code') }}',
                    data: 'coupon_code=' + coupon_code + '&_token=' + jQuery("[name='_token']").val(),
                    success: function(result) {
                        if (result.status == 'success') {
                            jQuery('.show_coupon_box').addClass('hide');
                            jQuery('#coupon_code_str').html('');
                            jQuery('#total_price').html('INR ' + result.totalPrice);
                            jQuery('.apply_coupon_code_box').show();
                            jQuery('#coupon_box').hide();
                        } else {

                        }
                        jQuery('#coupon_code_msg').html(result.msg);
                    }
                });
            }
        }
    </script>
@endsection
