@extends('front.layouts.app')


@section('content')
    <section class="breadcrub_section">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">
                        Product Categories
                    </li>
                </ol>
            </nav>
        </div>
    </section>
    <section class="category_section list-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12">
                    <div class="sidebar d-lg-block d-none">
                        <div class="main-menu ">
                            <h4 class="filter_heading">Filters</h4>
                            <nav>
                                <ul class="accordion" id="accordionPanelsStayOpenExample">
                                    <div class="item">
                                        <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                            <a href="#" class="link" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseOne">
                                                <span class="inner_heading">Category</span>
                                            </a>
                                        </h2>
                                        <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show"
                                            aria-labelledby="panelsStayOpen-headingOne">
                                            <div class="accordion-body">
                                                <ul class="">

                                                    @foreach ($categories_left as $cat_left)
                                                        @if ($slug == $cat_left->category_slug)
                                                            <li><a href="{{ url('category/' . $cat_left->category_slug) }}"
                                                                    class="left_cat_active">{{ $cat_left->category_name }}</a>
                                                            </li>
                                                        @else
                                                            <li><a
                                                                    href="{{ url('category/' . $cat_left->category_slug) }}">{{ $cat_left->category_name }}</a>
                                                            </li>
                                                        @endif
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="item">
                                        <form action="">
                                            <div class="wrapper">
                                                <div class="price-input">
                                                    <div class="field">
                                                        <span>Min</span>
                                                        <input id="skip-value-lower" type="number" class="input-min"
                                                            value="2500">
                                                    </div>
                                                    <div class="separator">-</div>
                                                    <div class="field">
                                                        <span>Max</span>
                                                        <input id="skip-value-upper" type="number" class="input-max"
                                                            value="7500">
                                                    </div>
                                                </div>
                                                <div class="slider">
                                                    <div class="progress"></div>
                                                </div>
                                                <div class="range-input">
                                                    <input type="range" class="range-min" min="0" max="10000"
                                                        value="2500" step="100">
                                                    <input type="range" class="range-max" min="0" max="10000"
                                                        value="7500" step="100">
                                                </div>
                                            </div>
                                            <div class="text-center mt-5">
                                                <button class="main-btn filter_btn border-0" type="button"
                                                    onclick="sort_price_filter()">Filter</button>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="item">
                                        <h2 class="accordion-header" id="panelsStayOpen-headingFour">
                                            <a href="#" class="link" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseFour" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseFour">
                                                <span class="inner_heading">Colors</span>
                                            </a>
                                        </h2>
                                        <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse show"
                                            aria-labelledby="panelsStayOpen-headingFour">
                                            <div class="accordion-body">
                                                <ul class="d-flex align-items-center justify-content-center">
                                                    @foreach ($colors as $color)
                                                        @if (in_array($color->id, $colorFilterArr))
                                                            <div class="form-check color_filter">

                                                                <input class="form-radio " type="radio" name="radio"
                                                                    id="{{ $color->color }}" value="{{ $color->color }}"
                                                                    onclick="setColor('{{ $color->id }}','1')" />
                                                                <label class="product_color "
                                                                    for="{{ strtolower($color->color) }}"
                                                                    style="background-color:{{ strtolower($color->color) }}"></label>
                                                            </div>
                                                        @else
                                                            <div class="form-check color_filter">
                                                                <input class="form-radio " type="radio" name="radio"
                                                                    id="{{ $color->color }}" value="{{ $color->color }}"
                                                                    onclick="setColor('{{ $color->id }}','0')" />
                                                                <label class="product_color "
                                                                    for="{{ strtolower($color->color) }}"
                                                                    style="background-color:{{ strtolower($color->color) }}"></label>
                                                            </div>
                                                        @endif
                                                    @endforeach

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                </ul>
                            </nav>
                        </div>
                    </div>
                    <div class="mobile_filter" style="display:none;">
                        <img src="images/close_icon.svg" class="close_icon">
                        <div class="main-menu ">
                            <h4 class="filter_heading">Filters</h4>
                            <nav>
                                <div class="accordion" id="accordionExample">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingOne">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapseOne" aria-expanded="true"
                                                aria-controls="collapseOne">
                                                Filters Material
                                            </button>
                                        </h2>
                                        <div id="collapseOne" class="accordion-collapse collapse show"
                                            aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    @foreach ($categories_left as $cat_left)
                                                        @if ($slug == $cat_left->category_slug)
                                                            <li><a href="{{ url('category/' . $cat_left->category_slug) }}"
                                                                    class="left_cat_active">{{ $cat_left->category_name }}</a>
                                                            </li>
                                                        @else
                                                            <li><a
                                                                    href="{{ url('category/' . $cat_left->category_slug) }}">{{ $cat_left->category_name }}</a>
                                                            </li>
                                                        @endif
                                                    @endforeach

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingThree">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapseThree"
                                                aria-expanded="false" aria-controls="collapseThree">
                                                Filters by Price
                                            </button>
                                        </h2>
                                        <div id="collapseThree" class="accordion-collapse collapse"
                                            aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    <input id="myinput" min="0" max="60" type="range"
                                                        value="30">
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="headingFour">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#collapseFour"
                                                aria-expanded="false" aria-controls="collapseFour">
                                                Colors
                                            </button>
                                        </h2>
                                        <div id="collapseFour" class="accordion-collapse collapse"
                                            aria-labelledby="headingFour" data-bs-parent="#accordionExample">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    @foreach ($colors as $color)
                                                        @if (in_array($color->id, $colorFilterArr))
                                                            <div class="form-check">

                                                                <input class="form-radio " type="radio" name="radio"
                                                                    id="{{ $color->color }}" value="{{ $color->color }}"
                                                                    onclick="setColor('{{ $color->id }}','1')" />
                                                                <label class="product_color "
                                                                    for="{{ strtolower($color->color) }}"
                                                                    style="background-color:{{ strtolower($color->color) }}"></label>
                                                            </div>
                                                        @else
                                                            <div class="form-check">


                                                                <input class="form-radio " type="radio" name="radio"
                                                                    id="{{ $color->color }}" value="{{ $color->color }}"
                                                                    onclick="setColor('{{ $color->id }}','0')" />
                                                                <label class="product_color "
                                                                    for="{{ strtolower($color->color) }}"
                                                                    style="background-color:{{ strtolower($color->color) }}"></label>
                                                            </div>
                                                        @endif
                                                    @endforeach

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </nav>
                            {{-- <div class="filter_row text-center mt-5">
                                <a href="" class="main-btn">Filter</a>
                            </div> --}}
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-12">
                    <div class="btn_row">
                        <span class="d-xl-inline d-none">Showing 1-16 of 72 results</span>
                        <a href="javascript:void()" class="d-xl-none d-inline main-btn filter_toggle">Filter</a>
                        <div>
                            {{-- <select class="main-btn">
                          <option>Sort By Price</option>
                        </select> --}}

                            <form action="" class="aa-sort-form">

                                <select class="main-btn" name="" onchange="sort_by()" id="sort_by_value">
                                    <option value="" selected="Default">Sort By</option>
                                    <option value="name">Name</option>
                                    <option value="price_desc">Price - Desc</option>
                                    <option value="price_asc">Price - Asc</option>
                                    <option value="date">Date</option>
                                </select>
                                {{ $sort_txt }}
                            </form>

                        </div>
                    </div>
                    <div class="list-item">
                        <div class="row">
                            @if (isset($product[0]))
                                @foreach ($product as $productArr)
                                    <div class="col-xl-4 col-md-6 col-12">
                                        <div class="product_box">
                                            <a href="{{ url('product/' . $productArr->alias) }}">
                                                <div class="part_img">
                                                    <img src="{{ asset('storage/app/public/media/' . $productArr->image) }}"
                                                        class="featured_product" height="100" width="100" />
                                                </div>
                                            </a>
                                            <div class="part_text">
                                                <a href="{{ url('product/' . $productArr->alias) }}">
                                                    <h5 class="product_name">{{ $productArr->title }}</h5>
                                                    <p class="deleted_price">AED
                                                        {{ $product_attr[$productArr->id][0]->price }}</p>
                                                    <p class="final_price">AED
                                                        {{ $product_attr[$productArr->id][0]->mrp }}</p>
                                                </a>
                                                <div class="product_footer">
                                                    <a href="{{ url('product/' . $productArr->alias) }}"
                                                        class="bordered_btn">Buy
                                                        Now</a>
                                                    <a href="javascript:void(0)"
                                                        onClick="home_add_to_cart('{{ $productArr->id }}','{{ $product_attr[$productArr->id][0]->size }}','{{ $product_attr[$productArr->id][0]->color }}')"
                                                        class="cart_box"><img
                                                            src="{{ asset('public/front/images/bag.svg') }}" /></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <figure>
                                    No data found
                                    <figure>
                            @endif
                        </div>
                    </div>
                    <div class="list-item" style="display: none;">
                        <div class="row">
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="product_box"><a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product">
                                        </div>
                                    </a>
                                    <div class="part_text"><a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer"><a href="#">
                                            </a><a href="product_detail.html" class="bordered_btn">Buy Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div id="pagination-container" class="pagination-container light-theme simple-pagination">
                        {{ $product->links() }}
                    </div>
                </div>
            </div>
        </div>
    </section>
    {{-- <section class="category_section list-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12">
                    <div class="sidebar" style="display: inline-block">
                        <img src="images/close_icon.svg" class="close_icon d-xl-none d-inline" />
                        <div class="main-menu">
                            <h4 class="filter_heading">Filters</h4>
                            <nav>
                                <ul class="accordion" id="accordionPanelsStayOpenExample">
                                    <div class="item">
                                        <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                            <a href="#" class="link" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseOne">
                                                <span class="inner_heading">Material</span>
                                            </a>
                                        </h2>
                                        <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show"
                                            aria-labelledby="panelsStayOpen-headingOne">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    @foreach ($categories_left as $cat_left)
                                                        @if ($slug == $cat_left->category_slug)
                                                            <li><a href="{{ url('category/' . $cat_left->category_slug) }}"
                                                                    class="left_cat_active">{{ $cat_left->category_name }}</a>
                                                            </li>
                                                        @else
                                                            <li><a
                                                                    href="{{ url('category/' . $cat_left->category_slug) }}">{{ $cat_left->category_name }}</a>
                                                            </li>
                                                        @endif
                                                    @endforeach

                                                </ul>
                                            </div>
                                        </div>
                                    </div> 
                                    <div class="item">
                                        <h2 class="accordion-header" id="panelsStayOpen-headingThree">
                                            <a href="#" class="link" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseThree">
                                                <span class="inner_heading">Filters by Price</span>
                                            </a>
                                        </h2>
                                        <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse show"
                                            aria-labelledby="panelsStayOpen-headingThree">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    <form action="">
                                                        <div id="skipstep"
                                                            class="noUi-target noUi-ltr noUi-horizontal noUi-background">
                                                        </div>
                                                        <span id="skip-value-lower" class="example-val">30.00</span>
                                                        <span id="skip-value-upper" class="example-val">100.00</span>
                                                        <button class="aa-filter-btn" type="button"
                                                            onclick="sort_price_filter()">Filter</button>
                                                    </form>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item">
                                        <h2 class="accordion-header" id="panelsStayOpen-headingFour">
                                            <a href="#" class="link" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseFour" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseFour">
                                                <span class="inner_heading">Colors</span>
                                            </a>
                                        </h2>
                                        <div id="panelsStayOpen-collapseFour" class="accordion-collapse collapse show"
                                            aria-labelledby="panelsStayOpen-headingFour">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    @foreach ($colors as $color)
                                                        @if (in_array($color->id, $colorFilterArr))
                                                            <a class="aa-color-{{ strtolower($color->color) }} active_color"
                                                                href="javascript:void(0)"
                                                                onclick="setColor('{{ $color->id }}','1')"></a>
                                                        @else
                                                            <a class="aa-color-{{ strtolower($color->color) }}"
                                                                href="javascript:void(0)"
                                                                onclick="setColor('{{ $color->id }}','0')"></a>
                                                        @endif
                                                    @endforeach

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="item border-0">
                                        <h2 class="accordion-header" id="panelsStayOpen-headingFive">
                                            <a href="#" class="link" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#panelsStayOpen-collapseFive" aria-expanded="true"
                                                aria-controls="panelsStayOpen-collapseFive">
                                                <span class="inner_heading">Weight</span>
                                            </a>
                                        </h2>
                                        <div id="panelsStayOpen-collapseFive" class="accordion-collapse collapse show"
                                            aria-labelledby="panelsStayOpen-headingFive">
                                            <div class="accordion-body">
                                                <ul class="">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value=""
                                                            id="60kg" checked />
                                                        <label class="form-check-label" for="60kg">
                                                            <span>60KG</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value=""
                                                            id="80KG" checked />
                                                        <label class="form-check-label" for="80KG">
                                                            <span>80KG</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value=""
                                                            id="90KG" checked />
                                                        <label class="form-check-label" for="90KG">
                                                            <span>90KG</span>
                                                        </label>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" value=""
                                                            id="100KG" checked />
                                                        <label class="form-check-label" for="100KG">
                                                            <span>100KG</span>
                                                        </label>
                                                    </div>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-12">
                    <div class="btn_row">
                        <div class="aa-product-catg-head-left">
                            <form action="" class="aa-sort-form">
                                <label for="">Sort by</label>
                                <select name="" onchange="sort_by()" id="sort_by_value">
                                    <option value="" selected="Default">Default</option>
                                    <option value="name">Name</option>
                                    <option value="price_desc">Price - Desc</option>
                                    <option value="price_asc">Price - Asc</option>
                                    <option value="date">Date</option>
                                </select>
                            </form>
                            {{ $sort_txt }}
                        </div>
                    </div>
                    <div class="list-item">
                        <div class="row">
                            @if (isset($product[0]))
                                @foreach ($product as $productArr)
                                    <div class="col-xl-4 col-md-6 col-12">
                                        <div class="product_box">
                                            <a href="{{ url('product/' . $productArr->alias) }}">
                                                <div class="part_img">
                                                    <img src="{{ asset('public/storage/media/' . $productArr->image) }}"
                                                        class="featured_product" />
                                                </div>
                                            </a>
                                            <div class="part_text">
                                                <a href="{{ url('product/' . $productArr->alias) }}">
                                                    <h5 class="product_name">{{ $productArr->title }}</h5>
                                                    <p class="deleted_price">AED
                                                        {{ $product_attr[$productArr->id][0]->price }}</p>
                                                    <p class="final_price">AED
                                                        {{ $product_attr[$productArr->id][0]->mrp }}</p>
                                                </a>
                                                <div class="product_footer">
                                                    <a href="{{ url('product/' . $productArr->alias) }}"
                                                        class="bordered_btn">Buy
                                                        Now</a>
                                                    <a href="javascript:void(0)"
                                                        onClick="home_add_to_cart('{{ $productArr->id }}','{{ $product_attr[$productArr->id][0]->size }}','{{ $product_attr[$productArr->id][0]->color }}')"
                                                        class="cart_box"><img
                                                            src="{{ asset('public/front/images/bag.svg') }}" /></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <figure>
                                    No data found
                                    <figure>
                            @endif
                        </div>
                    </div>
                    <div class="list-item" style="display: none">
                        <div class="row">
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-4 col-md-6 col-12 mt-4">
                                <div class="product_box">
                                    <a href="#">
                                        <div class="part_img">
                                            <img src="images/featured_product1.png" class="featured_product" />
                                        </div>
                                    </a>
                                    <div class="part_text">
                                        <a href="#">
                                            <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                            <p class="deleted_price">AED 90</p>
                                            <p class="final_price">AED 299</p>
                                        </a>
                                        <div class="product_footer">
                                            <a href="#"> </a><a href="product_detail.html" class="bordered_btn">Buy
                                                Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="pagination-container" class="pagination-container light-theme simple-pagination">
                        <ul>
                            <li class="active"><span class="current prev">«</span></li>
                            <li class="active"><span class="current">1</span></li>
                            <li><a href="#page-2" class="page-link">2</a></li>
                            <li><a href="#page-2" class="page-link next">»</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section> --}}
    {{-- <section class="category_section arrivals_products">
        <div class="container position-relative">
            <div class="main_heading mb-lg-5 mb-3">
                <h4>Chosen by our experts</h4>
            </div>
            <div class="row">
                <div class="offer-product-swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide" data-aos="fade-up">
                            <a href="#">
                                <div class="product_box">
                                    <div class="part_img">
                                        <img src="images/featured_product1.png" class="featured_product" />
                                        <div class="discount_text">
                                            <img src="images/offer_bg.svg" class="offer_bg" />
                                            <span class="main_span">10%<span class="off_text">off</span></span>
                                        </div>
                                    </div>
                                    <div class="part_text">
                                        <h5 class="product_name">Intex Sunset Glow Pool</h5>
                                        <p class="deleted_price">AED 90</p>
                                        <p class="final_price">AED 299</p>
                                        <div class="product_footer">
                                            <a href="product_detail.html" class="bordered_btn">Buy Now</a>
                                            <a href="#" class="cart_box"><img src="images/bag.svg" /></a>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="swiper-button-prev2">
                        <i class="fa-solid fa-arrow-left"></i>
                    </div>
                    <div class="swiper-button-next2">
                        <i class="fa-solid fa-arrow-right"></i>
                    </div>
                </div>
            </div>
        </div>
    </section> --}}
    <input type="hidden" id="qty" value="1" />
    <form id="frmAddToCart">
        <input type="hidden" id="size_id" name="size_id" />
        <input type="hidden" id="color_id" name="color_id" />
        <input type="hidden" id="pqty" name="pqty" />
        <input type="hidden" id="product_id" name="product_id" />
        @csrf
    </form>
    <form id="categoryFilter">
        <input type="hidden" id="sort" name="sort" value="{{ $sort }}" />
        <input type="hidden" id="filter_price_start" name="filter_price_start" value="{{ $filter_price_start }}" />
        <input type="hidden" id="filter_price_end" name="filter_price_end" value="{{ $filter_price_end }}" />
        <input type="hidden" id="color_filter" name="color_filter" value="{{ $color_filter }}" />
    </form>
    <script>
        function home_add_to_cart(id, size_str_id, color_str_id) {

            jQuery('#color_id').val(color_str_id);
            jQuery('#size_id').val(size_str_id);
            add_to_cart(id, size_str_id, color_str_id);
        }

        function add_to_cart(id, size_str_id, color_str_id) {

            jQuery('#add_to_cart_msg').html('');
            var color_id = jQuery('#color_id').val();
            var size_id = jQuery('#size_id').val();

            if (size_str_id == 0) {
                size_id = 'no';
            }
            if (color_str_id == 0) {
                color_id = 'no';
            }
            if (size_id == '' && size_id != 'no') {
                jQuery('#add_to_cart_msg').html(
                    '<div class="alert alert-danger fade in alert-dismissible mt10"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Please select size</div>'
                );
            } else if (color_id == '' && color_id != 'no') {
                jQuery('#add_to_cart_msg').html(
                    '<div class="alert alert-danger fade in alert-dismissible mt10"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Please select color</div>'
                );
            } else {
                jQuery('#product_id').val(id);
                jQuery('#pqty').val(jQuery('#qty').val());
                jQuery.ajax({
                    url: "{{ url('add_to_cart') }}",
                    method: 'POST',
                    data: jQuery('#frmAddToCart').serialize(),
                    success: function(result) {
                        var totalPrice = 0;

                        if (result.msg == 'not_avaliable') {
                            alert(result.data);
                        } else {
                            alert("Product " + result.msg);
                            if (result.totalItem == 0) {
                                jQuery('.aa-cart-notify').html('0');
                                jQuery('.aa-cartbox-summary').remove();
                            } else {

                                jQuery('.aa-cart-notify').html(result.totalItem);
                                var html = '<ul>';
                                jQuery.each(result.data, function(arrKey, arrVal) {
                                    totalPrice = parseInt(totalPrice) + (parseInt(arrVal.qty) *
                                        parseInt(arrVal.price));
                                    html += '<li><a class="aa-cartbox-img" href="#"><img src="' +
                                        PRODUCT_IMAGE + '/' + arrVal.image +
                                        '" alt="img"></a><div class="aa-cartbox-info"><h4><a href="#">' +
                                        arrVal.name + '</a></h4><p> ' + arrVal.qty + ' * Rs  ' + arrVal
                                        .price + '</p></div></li>';
                                });

                            }
                            html +=
                                '<li><span class="aa-cartbox-total-title">Total</span><span class="aa-cartbox-total-price">Rs ' +
                                totalPrice + '</span></li>';
                            html += '</ul><a class="aa-cartbox-checkout aa-primary-btn" href="cart">Cart</a>';
                            console.log(html);
                            jQuery('.aa-cartbox-summary').html(html);
                        }
                    }
                });
            }
        }
    </script>
@endsection
