@extends('front.layouts.app')


@section('content')
    <section class="breadcrub_section">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">

                        {{ $product[0]->title }}
                    </li>
                </ol>
            </nav>
        </div>
    </section>

    <section class="product_detail_section">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-12">
                    <div class="green_section">
                        <div class="image_box">
                            <div class="tab-content" id="pills-tabContent">
                                <div class="inner_box_image">
                                    <img src="{{ asset('storage/app/public/media/' . $product[0]->image) }}"
                                        class="tab-pane fade show active" id="green_first" role="tabpanel" />

                                </div>
                            </div>
                            <div class="changable_image_row nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <div class="mini_img_box nav-item" role="presentation">
                                    <img src="{{ asset('storage/app/public/media/' . $product[0]->image) }}" class="active"
                                        id="green_first-tab" data-bs-toggle="pill" data-bs-target="#green_first"
                                        type="button" role="tab" aria-controls="green_first" aria-selected="true" />
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-lg-6 col-12">
                    <div class="product_detail_box">
                        <div class="discount_badge">
                            {{-- <p>5% off</p> --}}
                        </div>
                        <div class="product_name">
                            <h2>{{ $product[0]->title }}</h2>
                            <h2 class="sixty_kg_price">
                                AED <span id="price_display">{{ $product_attr[$product[0]->id][0]->price }}</span>
                                <span class="sixty_kg_price disable_price" id="mrp">AED
                                    {{ $product_attr[$product[0]->id][0]->mrp }}</span>
                            </h2>

                        </div>
                        <div class="product_description">
                            <p>
                                {{ $product[0]->desc }}
                            </p>
                        </div>
                        
                        <div class="price_panel">
                            <div class="radio_container row">
                                <span class="col-auto weight_border">Weight : </span>
                                <div class="changable_div col">
                                    <div class="row">

                                        @if ($product_attr[$product[0]->id][0]->size_id > 0)
                                            @php
                                                $arrSize = [];
                                                foreach ($product_attr[$product[0]->id] as $attr) {
                                                     
                                                    $arrSize[] = $attr->size;
                                                    $arrId[] = $attr->id;
                                                }
                                                
                                                $arrSize = array_unique($arrSize);
                                                
                                            
                                            @endphp
                                            @foreach ($arrSize as $index => $attr)
                                                @if ($attr != '')
                                                    <label class="price_box col" for="{{ str_replace(' ', '', $attr) }}">
                                                        <input class="form-radio1 size_link" type="radio" name="radio1"
                                                            id="{{ str_replace(' ', '', $attr) }}"
                                                            value="{{ $attr }}"
                                                            onclick="showColor('{{ str_replace(' ', '', $attr) }}','{{ $arrId[$index] }}')" />
                                                        <div class="inner_price_box">
                                                            <span>{{ $attr }}</span>
                                                        </div>
                                                    </label>
                                                @endif
                                            @endforeach
                                        @endif

                                    </div>
                                </div>
                            </div>
                        </div></br>
                        <div class="color_panel">
                            <div class="radio_container">
                                <span>Color : </span>
                                <div class="changable_div">
                                    @if ($product_attr[$product[0]->id][0]->color_id > 0)
                                        @foreach ($product_attr[$product[0]->id] as $attr)
                                            <input class="form-radio " type="radio" name="radio"
                                                id="{{ $attr->color }}" value="{{ $attr->color }}"
                                                onClick="change_product_color_image('{{ asset('storage/app/public/media/' . $attr->attr_image) }}','{{ $attr->color }}')" />
                                            <label class="product_color size_{{ str_replace(' ', '', $attr->size) }}"
                                                for="{{ strtolower($attr->color) }}"
                                                style="background-color:{{ strtolower($attr->color) }}"></label>
                                        @endforeach
                                    @endif

                                </div>
                            </div>
                        </div>
                        <div class="buy_row">
                            <a herf="#" class="outline_btn">
                                <div class="qty-container">
                                    <i class="fa fa-minus qty-btn-minus"></i>
                                    <input type="text" id="qty" name="qty" value="1" class="input-qty" />
                                    <i class="fa fa-plus qty-btn-plus"></i>
                                </div>
                            </a>
                            <a href="javascript:void(0)"
                                onclick="add_to_cart('{{ $product[0]->id }}','{{ $product_attr[$product[0]->id][0]->size_id }}','{{ $product_attr[$product[0]->id][0]->color_id }}')"
                                class="outline_btn add_to_cart_btn">
                                <img src="{{ asset('public/front/images/cart_icon.svg') }}" />Add To Cart
                            </a>
                            <a href="javascript:void(0)" class="outline_btn add_to_cart_btn"
                                onclick="add_to_wishlist('{{ $product[0]->id }}')">
                                <img src="{{ asset('public/front/images/like.svg') }}" class="pe-0" />
                            </a>
                            {{-- <button type="button" class="main-btn border-0">
                                Buy Now
                            </button> --}}
                        </div>
                        <div id="add_to_cart_msg"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="product_desc_section">
        <div class="container">

            {{-- @if ($product_attr[$product[0]->id][0] > 0) --}}

            <div class="product_table_row">
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto">Product Dimensions :</span>
                            <div class="col">
                                <span
                                    class="sixty_kg_price" id="product_dimension">{{ $product_attr[$product[0]->id][0]->product_dimension }}</span>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto">Cautions :</span>
                            <div class="col">
                                <span class="sixty_kg_price" id="cautions">{{ $product_attr[$product[0]->id][0]->cautions }}</span>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto">Package Dimensions :</span>
                            <div class="col">
                                <span
                                    class="sixty_kg_price" id="package_dimension">{{ $product_attr[$product[0]->id][0]->package_dimension }}</span>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto">Material : </span>
                            <div class="col">
                                <span class="sixty_kg_price" id="material">{{ $product_attr[$product[0]->id][0]->material }}</span>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto">Weight : </span>
                            <div class="col">
                                <span class="sixty_kg_price" id="weight">{{ $product_attr[$product[0]->id][0]->weight }}</span>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto">Recommended Age :</span>
                            <div class="col">
                                <span
                                    class="sixty_kg_price" id="recommended_age">{{ $product_attr[$product[0]->id][0]->recommended_age }}</span>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="product_detail row">
                            <span class="title_td col-auto" id="shipping_weight">Shipping Weight :</span>
                            <div class="col">
                                <span
                                    class="sixty_kg_price">{{ $product_attr[$product[0]->id][0]->shipping_weight }}</span>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- @endif --}}
        </div>
    </section>
    {{-- <section class="product_deacription">
        <div class="container">
            <div class="product_desc_header">
                <ul class="nav nav-pills" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="pills-first-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-first" type="button" role="tab" aria-controls="pills-first"
                            aria-selected="true">
                            Description
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-second-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-second" type="button" role="tab" aria-controls="pills-second"
                            aria-selected="false">
                            Name
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-third-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-third" type="button" role="tab" aria-controls="pills-third"
                            aria-selected="false">
                            Name
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="pills-forth-tab" data-bs-toggle="pill"
                            data-bs-target="#pills-forth" type="button" role="tab" aria-controls="pills-forth"
                            aria-selected="false">
                            Name
                        </button>
                    </li>
                </ul>
            </div>
            <div class="product_desc_body">
                <div class="tab-content" id="pills-tabContent">
                    <div class="tab-pane fade show active" id="pills-first" role="tabpanel"
                        aria-labelledby="pills-first-tab">
                        <div class="desc_box">
                            <p class="mb-5">
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                            <p>
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape Kids
                                Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-second" role="tabpanel" aria-labelledby="pills-second-tab">
                        <div class="desc_box">
                            <p class="mb-5">
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                            <p>
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape Kids
                                Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-third" role="tabpanel" aria-labelledby="pills-third-tab">
                        <div class="desc_box">
                            <p class="mb-5">
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                            <p>
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape Kids
                                Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="pills-forth" role="tabpanel" aria-labelledby="pills-forth-tab">
                        <div class="desc_box">
                            <p class="mb-5">
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                            <p>
                                Kids Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape Kids
                                Flippy Floppy Spring rocker Cum Glider By is an outdoor
                                Dream Come True. Your Kids would love rocking on it! . Its
                                made with High quality plastic & strong iron base at the
                                bottom with heavy duty spring and its tweaks your kids
                                sensory stimulation. The spring movement helps to develop
                                coordination and balance. This rocking seesaw enhances kids
                                muscle strength.& develops strength of the upper and lower
                                parts of the body and supports motor planning and vestibular
                                activities. An ideal tool for kids who wants to develop
                                their Motor skills. Perfect Playset for Amusement parks,
                                Gardens, Outdoors, Schools, Shopping Malls & Landscape
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> --}}
    <section class="category_section">
        <div class="container position-relative">
            <div class="main_heading mb-lg-5 mb-3">
                <h4>Chosen by our experts</h4>
            </div>
            <div class="row">
                <div class="featured-swiper">
                    <div class="swiper-wrapper">
                        @if (isset($related_product[0]))
                            @foreach ($related_product as $productArr)
                                <div class="swiper-slide" data-aos="fade-up">
                                    <a href="#">
                                        <div class="product_box">
                                            <div class="part_img">
                                                <img src="{{ asset('storage/app/public/media/' . $productArr->image) }}"
                                                    class="featured_product" />
                                                {{-- <div class="discount_text">
                                            <img src="images/offer_bg.svg" class="offer_bg" />
                                            <span class="main_span">25%<span class="off_text">off</span></span>
                                        </div> --}}
                                            </div>
                                            <div class="part_text">
                                                <h5 class="product_name">{{ $productArr->title }}</h5>
                                                <p class="deleted_price">AED
                                                    {{ $related_product_attr[$productArr->id][0]->price }}</p>
                                                <p class="final_price">AED
                                                    {{ $related_product_attr[$productArr->id][0]->mrp }}</p>
                                                <div class="product_footer">
                                                    <a href="#" class="bordered_btn">Buy Now</a>
                                                    <a href="#" class="cart_box"><img
                                                            src="{{ asset('public/front/images/bag.svg') }}" /></a>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            @endforeach
                        @else
                            <p>
                            <figure>
                                No data found
                                <figure>
                                    </p>
                        @endif

                    </div>
                    <div class="swiper-button-prev1">
                        <i class="fa-solid fa-arrow-left"></i>
                    </div>
                    <div class="swiper-button-next1">
                        <i class="fa-solid fa-arrow-right"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <input type="hidden" name="product_id" value="{{ $product[0]->id }}" />
    <form id="frmAddToCart">
        <input type="hidden" id="size_id" name="size_id" />
        <input type="hidden" id="color_id" name="color_id" />
        <input type="hidden" id="pqty" name="pqty" />
        <input type="hidden" id="product_id" name="product_id" />
        @csrf
    </form>

    <form id="frmAddToWishList">
        {{-- <input type="hidden" id="size_id" name="size_id" />
        <input type="hidden" id="color_id" name="color_id" />
        <input type="hidden" id="pqty" name="pqty" /> --}}
        <input type="hidden" id="product_id" name="product_id" />
        @csrf
    </form>


    <script>
        function home_add_to_cart(id, size_str_id, color_str_id) {

            jQuery('#color_id').val(color_str_id);
            jQuery('#size_id').val(size_str_id);
            add_to_cart(id, size_str_id, color_str_id);
        }



        function add_to_cart(id, size_str_id, color_str_id) {
            // alert(id);
            jQuery('#add_to_cart_msg').html('');
            var color_id = jQuery('#color_id').val();
            var size_id = jQuery('#size_id').val();


            if (size_str_id == 0) {
                size_id = 'no';
            }
            if (color_str_id == 0) {
                color_id = 'no';
            }
            if (size_id == '' && size_id != 'no') {
                jQuery('#add_to_cart_msg').html(
                    '<div class="alert alert-danger fade in alert-dismissible mt10"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Please select size</div>'
                );
            } else if (color_id == '' && color_id != 'no') {
                jQuery('#add_to_cart_msg').html(
                    '<div class="alert alert-danger fade in alert-dismissible mt10"><a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>Please select color</div>'
                );
            } else {
                jQuery('#product_id').val(id);
                jQuery('#pqty').val(jQuery('#qty').val());
                jQuery.ajax({
                    url: "{{ url('add_to_cart') }}",
                    method: 'POST',
                    data: jQuery('#frmAddToCart').serialize(),
                    success: function(result) {
                        var totalPrice = 0;

                        if (result.msg == 'not_avaliable') {
                            alert(result.data);
                        } else {
                            alert("Product " + result.msg);
                            if (result.totalItem == 0) {
                                jQuery('.aa-cart-notify').html('0');
                                jQuery('.aa-cartbox-summary').remove();
                            } else {

                                jQuery('.aa-cart-notify').html(result.totalItem);
                                var html = '<ul>';
                                jQuery.each(result.data, function(arrKey, arrVal) {
                                    totalPrice = parseInt(totalPrice) + (parseInt(arrVal.qty) *
                                        parseInt(arrVal.price));
                                    html += '<li><a class="aa-cartbox-img" href="#"><img src="' +
                                        PRODUCT_IMAGE + '/' + arrVal.image +
                                        '" alt="img"></a><div class="aa-cartbox-info"><h4><a href="#">' +
                                        arrVal.name + '</a></h4><p> ' + arrVal.qty + ' * Rs  ' + arrVal
                                        .price + '</p></div></li>';
                                });

                            }
                            html +=
                                '<li><span class="aa-cartbox-total-title">Total</span><span class="aa-cartbox-total-price">Rs ' +
                                totalPrice + '</span></li>';
                            html += '</ul><a class="aa-cartbox-checkout aa-primary-btn" href="cart">Cart</a>';
                            console.log(html);
                            jQuery('.aa-cartbox-summary').html(html);
                        }
                    }
                });
            }
        }

        function add_to_wishlist(id) {


            var csrfToken = "{{ csrf_token() }}"; // Get the CSRF token value from Laravel

            var data = {
                _token: csrfToken,
                id: id
            };
            // jQuery('#pqty').val(jQuery('#qty').val());
            jQuery.ajax({
                url: "{{ url('add_to_wishlist') }}",
                method: 'POST',
                data: data,
                success: function(result) {

                    if (result.status == 'error') {
                        window.location.href = "../login-register";

                    } else {
                        var totalPrice = 0;

                        if (result.msg == 'not_avaliable') {
                            alert(result.data);
                        } else {
                            alert("Product " + result.msg);
                            if (result.totalItem == 0) {
                                jQuery('.aa-cart-notify2').html('0');
                                jQuery('.aa-cartbox-summary').remove();
                            } else {

                                jQuery('.aa-cart-notify2').html(result.totalItem);
                                var html = '<ul>';
                                jQuery.each(result.data, function(arrKey, arrVal) {
                                    totalPrice = parseInt(totalPrice) + (parseInt(arrVal.qty) *
                                        parseInt(arrVal.price));
                                    html += '<li><a class="aa-cartbox-img" href="#"><img src="' +
                                        PRODUCT_IMAGE + '/' + arrVal.image +
                                        '" alt="img"></a><div class="aa-cartbox-info"><h4><a href="#">' +
                                        arrVal.name + '</a></h4><p> ' + arrVal.qty + ' * Rs  ' + arrVal
                                        .price + '</p></div></li>';
                                });

                            }
                            html +=
                                '<li><span class="aa-cartbox-total-title">Total</span><span class="aa-cartbox-total-price">Rs ' +
                                totalPrice + '</span></li>';
                            html += '</ul><a class="aa-cartbox-checkout aa-primary-btn" href="cart">Cart</a>';
                            console.log(html);
                            jQuery('.aa-cartbox-summary').html(html);
                        }
                    }
                    //    / if(result.status=="error"){
                    //         console.log('yes');
                    //     }
                }
            });
        }


        function showColor(size,id){

  jQuery('#size_id').val(size);

  jQuery('.product_color').hide();
  jQuery('.size_'+size).show();
  jQuery('.size_link').css('border','1px solid #ddd');
  jQuery('#'+size).css('border','1px solid black');
  var csrfToken = jQuery('meta[name="csrf-token"]').attr('content');
  jQuery.ajax({
    url: '../get-price-data', // Replace with the appropriate URL to your controller action
    type: 'post',
    data: {
      _token: '{{ csrf_token() }}',
        size: size,
        id: id
    },
    success: function(response) {
        console.log(response.price);
        var price = response.price;
        var mrp = response.mrp;
        var product_dimension = response.product_dimension;
        var package_dimension = response.package_dimension;
        var weight = response.weight;
        var shipping_weight = response.shipping_weight;
        var cautions = response.cautions;
        var material = response.material;
        var recommended_age = response.recommended_age;


        // Update the price on your page
        jQuery('#price_display').text(price);
        jQuery('#mrp').text(mrp);
        jQuery('#product_dimension').text(product_dimension);
        jQuery('#package_dimension').text(package_dimension);
        jQuery('#weight').text(weight);
        jQuery('#shipping_weight').text(shipping_weight);
        jQuery('#cautions').text(cautions);
        jQuery('#material').text(material);
        jQuery('#recommended_age').text(recommended_age);
    },
    error: function(xhr, status, error) {
        // Handle error, if any
        console.log(error);
    }
});
 
}
    </script>
@endsection
