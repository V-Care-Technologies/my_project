@extends('front.layouts.app')
@section('page_title','Order Placed')

@section('content')

  <!-- product category -->
  <section class="my_account">
    <div class="container">
        <div class="row account_row">
            
            <div class="col-lg-12">
                <form id="save-form" class="validate" action="{{url('/my-account/update')}}" method="post" enctype="multipart/form-data" accept-charset="utf-8">
                  @csrf
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="input_box">
                                <h5>First Name</h5>
                                <input id="firstName" type="text" name="name" value="{{$first_name}}" class="appointment_input"  placeholder="First Name" data-validate="required" required  data-message-required="Enter Name">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="input_box">
                                <h5>Last Name</h5>
                                <input id="lastName" type="text" name="last_name" value="{{$last_name}}" placeholder="Last Name" data-validate="required" required  data-message-required="Enter Last Name">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="input_box">
                                <h5>Email</h5>
                                <input id="email" type="email" placeholder="Email" value="{{$email}}" name="email" data-validate="required" required  data-message-required="Enter Email">
                            </div>
                        </div> 
                        <div class="col-lg-12">
                            <div class="input_box">
                                <h5>Mobile Number</h5>
                                <input id="mobileNumber" type="number" value="{{$phone}}" placeholder="Mobile Number" name="phone" data-validate="required" required  data-message-required="Enter Moile Number"> 
                            </div>
                        </div> 
                        <div class="col-lg-12">
                            <div class="input_box">
                                <h5>Address.....</h5>
                                <textarea id="address" type="text" name="address" placeholder="Address....." rows="4" data-validate="required" required  data-message-required="Enter Address">{{$address}}</textarea>
                            </div>
                        </div> 
                        <input type="hidden" name="id" value="{{$id}}">
                        <div class="col-lg-12 submit_row">
                            <button type="submit" class="main-btn border-0">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
@endsection