@extends('front/layout')
@section('page_title','Order Fail')
@section('container')

  <!-- product category -->
<section id="aa-product-category">
   <div class="container">
      <div class="row" style="text-align:center;">
        <br/><br/><br/>
            <h2>Your order has been failed</h2>
        <br/><br/><br/>
      </div>
   </div>
</section>
@endsection